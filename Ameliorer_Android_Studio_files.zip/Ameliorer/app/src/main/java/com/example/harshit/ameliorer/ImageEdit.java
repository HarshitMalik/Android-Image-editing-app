package com.example.harshit.ameliorer;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v8.renderscript.Allocation;
import android.support.v8.renderscript.RenderScript;
import android.support.v8.renderscript.ScriptIntrinsicBlur;
import android.support.v8.renderscript.ScriptIntrinsicResize;
import android.support.v8.renderscript.Type;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.zomato.photofilters.FilterPack;
import com.zomato.photofilters.imageprocessors.Filter;
import com.zomato.photofilters.imageprocessors.subfilters.BrightnessSubFilter;
import com.zomato.photofilters.imageprocessors.subfilters.ContrastSubFilter;
import com.zomato.photofilters.imageprocessors.subfilters.SaturationSubfilter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ImageEdit extends AppCompatActivity {

    static
    {
        System.loadLibrary("NativeImageProcessor");
    }

    final int WIDTH = 480;

    ImageView imageView;
    HorizontalScrollView mainScrollView,filterScrollView,adjustScrollView,editScrollView,overlayScrollView;
    LinearLayout filtBtnLayout, editBtnLayout, adjustBtnLayout, overlayBtnLayout;

    ImageButton amazonFiltBtn, audreyFiltBtn, bluemessFiltBtn, clarendonFiltBtn,
            cruzFiltBtn, limeFiltBtn, marsFiltBtn, metropolisFiltBtn, oldmanFiltBtn,
            riseFiltBtn, starlitFiltBtn, struckFiltBtn;

    ImageButton beautifyBtn,filtBtn,editBtn,adjustBtn,stickerBtn,textBtn,doodleBtn,eraseBtn;

    ImageButton cropBtn,flipVertBtn,flipHorzBtn,rotateLeftBtn,rotateRightBtn;

    ImageButton brightBtn, contrastBtn, saturateBtn, sharpBtn, vignetteBtn;

    Button okFiltBtn, cancelFiltBtn, okAdjustBtn, cancelAdjustBtn, okEditBtn, cancelEditBtn,
            okOverlayBtn, cancelOverlayBtn;

    Uri inputImgUri = null;

    String TAG = "ImageEdit";
    
    Bitmap orgBmp,editedBmp,tempBmp;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_edit);

        RenderScript rs = RenderScript.create(getApplicationContext());

        inputImgUri = this.getIntent().getParcelableExtra("Uri");
        
        imageView = findViewById(R.id.imageView);
        mainScrollView = findViewById(R.id.mainScrollView);
        filterScrollView = findViewById(R.id.filterScrollView);
        adjustScrollView = findViewById(R.id.adjustScrollView);
        editScrollView = findViewById(R.id.editScrollView);
        overlayScrollView = findViewById(R.id.overlayScrollView);

        beautifyBtn = findViewById(R.id.beautifyBtn);
        filtBtn = findViewById(R.id.filtBtn);
        editBtn = findViewById(R.id.editBtn);
        adjustBtn = findViewById(R.id.adjustBtn);
        stickerBtn = findViewById(R.id.stickerBtn);
        textBtn = findViewById(R.id.textBtn);
        doodleBtn = findViewById(R.id.doodleBtn);
        eraseBtn = findViewById(R.id.eraseBtn);

        amazonFiltBtn = findViewById(R.id.amazonFiltBtn);
        audreyFiltBtn = findViewById(R.id.audreyFiltBtn);
        bluemessFiltBtn = findViewById(R.id.bluemessFiltBtn);
        clarendonFiltBtn = findViewById(R.id.clarendonFiltBtn);
        cruzFiltBtn = findViewById(R.id.cruzFiltBtn);
        limeFiltBtn = findViewById(R.id.limeFiltBtn);
        marsFiltBtn = findViewById(R.id.marsFiltBtn);
        metropolisFiltBtn = findViewById(R.id.metropolisFiltBtn);
        oldmanFiltBtn = findViewById(R.id.oldmanFiltBtn);
        riseFiltBtn = findViewById(R.id.riseFiltBtn);
        starlitFiltBtn = findViewById(R.id.starlitFiltBtn);
        struckFiltBtn = findViewById(R.id.struckFiltBtn);

        cropBtn = findViewById(R.id.cropBtn);
        flipVertBtn = findViewById(R.id.flipVertBtn);
        flipHorzBtn = findViewById(R.id.flipHorzBtn);
        rotateLeftBtn = findViewById(R.id.rotateLeftBtn);
        rotateRightBtn = findViewById(R.id.rotateRightBtn);

        brightBtn = findViewById(R.id.brightBtn);
        contrastBtn = findViewById(R.id.contrastBtn);
        saturateBtn = findViewById(R.id.saturateBtn);
        sharpBtn = findViewById(R.id.sharpBtn);
        vignetteBtn = findViewById(R.id.vignetteBtn);

        okFiltBtn = findViewById(R.id.okFiltBtn);
        cancelFiltBtn = findViewById(R.id.cancelFiltBtn);
        okAdjustBtn = findViewById(R.id.okAdjustBtn);
        cancelAdjustBtn = findViewById(R.id.cancelAdjustBtn);
        okEditBtn = findViewById(R.id.okEditBtn);
        cancelEditBtn = findViewById(R.id.cancelEditBtn);
        okOverlayBtn = findViewById(R.id.okOverlayBtn);
        cancelOverlayBtn = findViewById(R.id.cancelOverlayBtn);

        filtBtnLayout = findViewById(R.id.filtBtnLayout);
        adjustBtnLayout = findViewById(R.id.adjustBtnLayout);
        editBtnLayout = findViewById(R.id.editBtnLayout);
        overlayBtnLayout = findViewById(R.id.overlayBtnLayout);
        
        filterScrollView.setVisibility(View.INVISIBLE);
        adjustScrollView.setVisibility(View.INVISIBLE);
        overlayScrollView.setVisibility(View.INVISIBLE);
        editScrollView.setVisibility(View.INVISIBLE);

        filtBtnLayout.setVisibility(View.INVISIBLE);
        adjustBtnLayout.setVisibility(View.INVISIBLE);
        editBtnLayout.setVisibility(View.INVISIBLE);
        overlayBtnLayout.setVisibility(View.INVISIBLE);

        try {
            orgBmp = resizeBitmap2(rs, MediaStore.Images.Media.getBitmap(this.getContentResolver(), inputImgUri), WIDTH);
            editedBmp = orgBmp;
            tempBmp = orgBmp;
            imageView.setImageBitmap(editedBmp);
            
        } catch (IOException e) {
            e.printStackTrace();
        }

        amazonFiltBtn.setOnClickListener(filterListener);
        audreyFiltBtn.setOnClickListener(filterListener);
        bluemessFiltBtn.setOnClickListener(filterListener);
        clarendonFiltBtn.setOnClickListener(filterListener);
        cruzFiltBtn.setOnClickListener(filterListener);
        limeFiltBtn.setOnClickListener(filterListener);
        marsFiltBtn.setOnClickListener(filterListener);
        metropolisFiltBtn.setOnClickListener(filterListener);
        oldmanFiltBtn.setOnClickListener(filterListener);
        riseFiltBtn.setOnClickListener(filterListener);
        starlitFiltBtn.setOnClickListener(filterListener);
        struckFiltBtn.setOnClickListener(filterListener);

        beautifyBtn.setOnClickListener(mainListener);
        filtBtn.setOnClickListener(mainListener);
        editBtn.setOnClickListener(mainListener);
        adjustBtn.setOnClickListener(mainListener);
        stickerBtn.setOnClickListener(mainListener);
        textBtn.setOnClickListener(mainListener);
        doodleBtn.setOnClickListener(mainListener);
        eraseBtn.setOnClickListener(mainListener);

        cropBtn.setOnClickListener(editListener);
        flipVertBtn.setOnClickListener(editListener);
        flipHorzBtn.setOnClickListener(editListener);
        rotateLeftBtn.setOnClickListener(editListener);
        rotateRightBtn.setOnClickListener(editListener);

        brightBtn.setOnClickListener(adjustListener);
        contrastBtn.setOnClickListener(adjustListener);
        saturateBtn.setOnClickListener(adjustListener);
        sharpBtn.setOnClickListener(adjustListener);
        vignetteBtn.setOnClickListener(adjustListener);

        okFiltBtn.setOnClickListener(clickListener);
        cancelFiltBtn.setOnClickListener(clickListener);
        okAdjustBtn.setOnClickListener(clickListener);
        cancelAdjustBtn.setOnClickListener(clickListener);
        okEditBtn.setOnClickListener(clickListener);
        cancelEditBtn.setOnClickListener(clickListener);
        okOverlayBtn.setOnClickListener(clickListener);
        cancelOverlayBtn.setOnClickListener(clickListener);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_edit_image, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id) {
            case R.id.action_save:
                new SaveImage().execute(editedBmp);
                break;
            case R.id.action_settings:
                Toast.makeText(getApplicationContext(), "Setting clicked", Toast.LENGTH_SHORT).show();
                break;
            case R.id.action_about:
                Toast.makeText(getApplicationContext(), "About clicked", Toast.LENGTH_SHORT).show();
                break;
            case R.id.action_cancel:
                Toast.makeText(getApplicationContext(), "Cancel clicked", Toast.LENGTH_SHORT).show();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private View.OnClickListener filterListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId())
            {
                case R.id.amazonFiltBtn :
                    editedBmp = FilterPack.getAmazonFilter(getApplicationContext()).processFilter(orgBmp);
                    imageView.setImageBitmap(editedBmp);
                    break;

                case R.id.audreyFiltBtn :
                    editedBmp = FilterPack.getAudreyFilter(getApplicationContext()).processFilter(orgBmp);
                    imageView.setImageBitmap(editedBmp);
                    break;

                case R.id.bluemessFiltBtn :
                    editedBmp = FilterPack.getBlueMessFilter(getApplicationContext()).processFilter(orgBmp);
                    imageView.setImageBitmap(editedBmp);
                    break;

                case R.id.clarendonFiltBtn :
                    editedBmp = FilterPack.getClarendon(getApplicationContext()).processFilter(orgBmp);
                    imageView.setImageBitmap(editedBmp);
                    break;

                case R.id.cruzFiltBtn :
                    editedBmp = FilterPack.getCruzFilter(getApplicationContext()).processFilter(orgBmp);
                    imageView.setImageBitmap(editedBmp);
                    break;

                case R.id.limeFiltBtn :
                    editedBmp = FilterPack.getLimeStutterFilter(getApplicationContext()).processFilter(orgBmp);
                    imageView.setImageBitmap(editedBmp);
                    break;

                case R.id.marsFiltBtn :
                    editedBmp = FilterPack.getMarsFilter(getApplicationContext()).processFilter(orgBmp);
                    imageView.setImageBitmap(editedBmp);
                    break;

                case R.id.metropolisFiltBtn :
                    editedBmp = FilterPack.getMetropolis(getApplicationContext()).processFilter(orgBmp);
                    imageView.setImageBitmap(editedBmp);
                    break;

                case R.id.oldmanFiltBtn :
                    editedBmp = FilterPack.getOldManFilter(getApplicationContext()).processFilter(orgBmp);
                    imageView.setImageBitmap(editedBmp);
                    break;

                case R.id.starlitFiltBtn :
                    editedBmp = FilterPack.getStarLitFilter(getApplicationContext()).processFilter(orgBmp);
                    imageView.setImageBitmap(editedBmp);
                    break;

                case R.id.struckFiltBtn :
                    editedBmp = FilterPack.getAweStruckVibeFilter(getApplicationContext()).processFilter(orgBmp);
                    imageView.setImageBitmap(editedBmp);
                    break;

                default:
                    editedBmp = orgBmp;
                    imageView.setImageBitmap(editedBmp);
                    break;
            }
        }
    };

    private View.OnClickListener mainListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId())
            {
                case R.id.beautifyBtn :Toast.makeText(getApplicationContext(),"Feature coming soon",Toast.LENGTH_SHORT).show();
                    break;

                case R.id.filtBtn :
                    mainScrollView.setVisibility(View.INVISIBLE);
                    adjustScrollView.setVisibility(View.INVISIBLE);
                    editScrollView.setVisibility(View.INVISIBLE);
                    overlayScrollView.setVisibility(View.INVISIBLE);
                    filtBtnLayout.setVisibility(View.VISIBLE);
                    filterScrollView.setVisibility(View.VISIBLE);
                    tempBmp = editedBmp;
                    break;
                case R.id.editBtn :
                    mainScrollView.setVisibility(View.INVISIBLE);
                    adjustScrollView.setVisibility(View.INVISIBLE);
                    filterScrollView.setVisibility(View.INVISIBLE);
                    overlayScrollView.setVisibility(View.INVISIBLE);
                    editBtnLayout.setVisibility(View.VISIBLE);
                    editScrollView.setVisibility(View.VISIBLE);
                    tempBmp = editedBmp;
                    break;
                case R.id.adjustBtn :
                    mainScrollView.setVisibility(View.INVISIBLE);
                    filterScrollView.setVisibility(View.INVISIBLE);
                    editScrollView.setVisibility(View.INVISIBLE);
                    overlayScrollView.setVisibility(View.INVISIBLE);
                    adjustScrollView.setVisibility(View.VISIBLE);
                    adjustBtnLayout.setVisibility(View.VISIBLE);
                    tempBmp = editedBmp;
                    break;

                case R.id.stickerBtn:
                    mainScrollView.setVisibility(View.INVISIBLE);
                    filterScrollView.setVisibility(View.INVISIBLE);
                    editScrollView.setVisibility(View.INVISIBLE);
                    adjustScrollView.setVisibility(View.INVISIBLE);
                    overlayScrollView.setVisibility(View.VISIBLE);
                    overlayBtnLayout.setVisibility(View.VISIBLE);
                    tempBmp = editedBmp;
                    break;

                case R.id.textBtn :
                    Toast.makeText(getApplicationContext(),"Feature coming soon",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.doodleBtn :
                    Toast.makeText(getApplicationContext(),"Feature coming soon",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.eraseBtn :
                    Toast.makeText(getApplicationContext(),"Feature coming soon",Toast.LENGTH_SHORT).show();
                    break;
                default: break;

            }
        }
    };

    private View.OnClickListener editListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId())
            {
                case R.id.cropBtn :
                    Toast.makeText(getApplicationContext(),"Feature coming soon",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.flipVertBtn :
                    editedBmp = flipVert();
                    imageView.setImageBitmap(editedBmp);
                    break;
                case R.id.flipHorzBtn :
                    editedBmp = flipHorz();
                    imageView.setImageBitmap(editedBmp);
                    break;
                case R.id.rotateLeftBtn :
                    editedBmp = rotateLeft();
                    imageView.setImageBitmap(editedBmp);
                    break;
                case R.id.rotateRightBtn :
                    editedBmp = rotateRight();
                    imageView.setImageBitmap(editedBmp);
                    break;
                default: break;
            }
        }
    };

    private View.OnClickListener adjustListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId())
            {
                case R.id.brightBtn :
                    Filter bright = new Filter();
                    bright.addSubFilter(new BrightnessSubFilter(30));
                    editedBmp = bright.processFilter(editedBmp);
                    imageView.setImageBitmap(editedBmp);
                    break;
                case R.id.contrastBtn :
                    Filter contrast = new Filter();
                    contrast.addSubFilter(new ContrastSubFilter(1.3f));
                    editedBmp = contrast.processFilter(editedBmp);
                    imageView.setImageBitmap(editedBmp);
                    break;
                case R.id.saturateBtn :
                    Filter saturate = new Filter();
                    saturate.addSubFilter(new SaturationSubfilter(1.3f));
                    editedBmp = saturate.processFilter(editedBmp);
                    imageView.setImageBitmap(editedBmp);
                    break;
                case R.id.sharpBtn :
                    Toast.makeText(getApplicationContext(),"Feature coming soon",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.vignetteBtn :
                    Filter vignette = new Filter();
                    vignette.addSubFilter(new ContrastSubFilter(1.3f));
                    editedBmp = vignette.processFilter(editedBmp);
                    imageView.setImageBitmap(editedBmp);
                    break;
                default: break;
            }
        }
    };

    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId())
            {
                case R.id.okFiltBtn :
                    filtBtnLayout.setVisibility(View.INVISIBLE);
                    filterScrollView.setVisibility(View.INVISIBLE);
                    mainScrollView.setVisibility(View.VISIBLE);
                    break;

                case R.id.cancelFiltBtn :
                    filtBtnLayout.setVisibility(View.INVISIBLE);
                    filterScrollView.setVisibility(View.INVISIBLE);
                    mainScrollView.setVisibility(View.VISIBLE);
                    imageView.setImageBitmap(editedBmp);
                    editedBmp = ((BitmapDrawable)imageView.getDrawable()).getBitmap();
                    break;

                case R.id.okAdjustBtn :
                    adjustBtnLayout.setVisibility(View.INVISIBLE);
                    adjustScrollView.setVisibility(View.INVISIBLE);
                    mainScrollView.setVisibility(View.VISIBLE);
                    break;

                case R.id.cancelAdjustBtn :
                    adjustBtnLayout.setVisibility(View.INVISIBLE);
                    adjustScrollView.setVisibility(View.INVISIBLE);
                    mainScrollView.setVisibility(View.VISIBLE);
                    imageView.setImageBitmap(editedBmp);
                    editedBmp = ((BitmapDrawable)imageView.getDrawable()).getBitmap();
                    break;

                case R.id.okEditBtn :
                    editBtnLayout.setVisibility(View.INVISIBLE);
                    editScrollView.setVisibility(View.INVISIBLE);
                    mainScrollView.setVisibility(View.VISIBLE);
                    break;

                case R.id.cancelEditBtn :
                    editBtnLayout.setVisibility(View.INVISIBLE);
                    editScrollView.setVisibility(View.INVISIBLE);
                    mainScrollView.setVisibility(View.VISIBLE);
                    imageView.setImageBitmap(tempBmp);
                    editedBmp = ((BitmapDrawable)imageView.getDrawable()).getBitmap();
                    break;

                case R.id.okOverlayBtn :
                    overlayBtnLayout.setVisibility(View.INVISIBLE);
                    overlayScrollView.setVisibility(View.INVISIBLE);
                    mainScrollView.setVisibility(View.VISIBLE);
                    break;

                case R.id.cancelOverlayBtn :
                    overlayBtnLayout.setVisibility(View.INVISIBLE);
                    overlayScrollView.setVisibility(View.INVISIBLE);
                    mainScrollView.setVisibility(View.VISIBLE);
                    imageView.setImageBitmap(editedBmp);
                    editedBmp = ((BitmapDrawable)imageView.getDrawable()).getBitmap();
                    break;

                default: break;

            }
        }
    };

    public static Bitmap resizeBitmap2(RenderScript rs, Bitmap src, int dstWidth) {
        Bitmap.Config bitmapConfig = src.getConfig();
        int srcWidth = src.getWidth();
        int srcHeight = src.getHeight();
        float srcAspectRatio = (float) srcWidth / srcHeight;
        int dstHeight = (int) (dstWidth / srcAspectRatio);

        float resizeRatio = (float) srcWidth / dstWidth;

        /* Calculate gaussian's radius */
        float sigma = resizeRatio / (float) Math.PI;
        // https://android.googlesource.com/platform/frameworks/rs/+/master/cpu_ref/rsCpuIntrinsicBlur.cpp
        float radius = 2.5f * sigma - 1.5f;
        radius = Math.min(25, Math.max(0.0001f, radius));

        /* Gaussian filter */
        Allocation tmpIn = Allocation.createFromBitmap(rs, src);
        Allocation tmpFiltered = Allocation.createTyped(rs, tmpIn.getType());
        ScriptIntrinsicBlur blurInstrinsic = ScriptIntrinsicBlur.create(rs, tmpIn.getElement());

        blurInstrinsic.setRadius(radius);
        blurInstrinsic.setInput(tmpIn);
        blurInstrinsic.forEach(tmpFiltered);

        tmpIn.destroy();
        blurInstrinsic.destroy();

        /* Resize */
        Bitmap dst = Bitmap.createBitmap(dstWidth, dstHeight, bitmapConfig);
        Type t = Type.createXY(rs, tmpFiltered.getElement(), dstWidth, dstHeight);
        Allocation tmpOut = Allocation.createTyped(rs, t);
        ScriptIntrinsicResize resizeIntrinsic = ScriptIntrinsicResize.create(rs);

        resizeIntrinsic.setInput(tmpFiltered);
        resizeIntrinsic.forEach_bicubic(tmpOut);
        tmpOut.copyTo(dst);

        tmpFiltered.destroy();
        tmpOut.destroy();
        resizeIntrinsic.destroy();

        return dst;
    }

    private void storeImage(Bitmap image) {
        File pictureFile = getOutputMediaFile();
        if (pictureFile == null) {
            Log.d(TAG,
                    "Error creating media file, check storage permissions: ");// e.getMessage());
            return;
        }
        try {
            FileOutputStream fos = new FileOutputStream(pictureFile);
            image.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();
        } catch (FileNotFoundException e) {
            Log.d(TAG, "File not found: " + e.getMessage());
        } catch (IOException e) {
            Log.d(TAG, "Error accessing file: " + e.getMessage());
        }
    }

    /* Create a File for saving an image or video */
    private File getOutputMediaFile() {
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this.
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
                + "/Ameliorer");

        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                return null;
            }
        }
        // Create a media file name
        String timeStamp = new SimpleDateFormat("ddMMyyyy_HHmm").format(new Date());
        File mediaFile;
        String mImageName = "AMELIORER_" + timeStamp + ".jpg";
        mediaFile = new File(mediaStorageDir.getPath() + File.separator + mImageName);
        return mediaFile;
    }

    class SaveImage extends AsyncTask<Bitmap, Void, Void> {

        @Override
        protected Void doInBackground(Bitmap... bmp) {

            Bitmap image = bmp[0];

            // To be safe, you should check that the SDCard is mounted
            // using Environment.getExternalStorageState() before doing this.
            File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
                    + "/Ameliorer");

            // This location works best if you want the created images to be shared
            // between applications and persist after your app has been uninstalled.

            // Create the storage directory if it does not exist
            if (!mediaStorageDir.exists()) {
                if (!mediaStorageDir.mkdirs()) {
                    return null;
                }
            }
            // Create a media file name
            String timeStamp = new SimpleDateFormat("ddMMyyyy_HHmm").format(new Date());
            File mediaFile;
            String mImageName = "AMELIORER_" + timeStamp + ".jpg";
            mediaFile = new File(mediaStorageDir.getPath() + File.separator + mImageName);

            File pictureFile = mediaFile;
            if (pictureFile == null) {
                Log.d(TAG,
                        "Error creating media file, check storage permissions: ");// e.getMessage());
                return null;
            }
            try {
                FileOutputStream fos = new FileOutputStream(pictureFile);
                image.compress(Bitmap.CompressFormat.PNG, 100, fos);
                fos.close();
            } catch (FileNotFoundException e) {
                Log.d(TAG, "File not found: " + e.getMessage());
            } catch (IOException e) {
                Log.d(TAG, "Error accessing file: " + e.getMessage());
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            Toast.makeText(getApplicationContext(),"Image Saved To DCIM",Toast.LENGTH_LONG).show();
        }
    }

    private Bitmap flipVert(){

        Bitmap photo = Bitmap.createBitmap(editedBmp.getWidth(),editedBmp.getHeight(),editedBmp.getConfig());


        int A,R,G,B;
        int height=editedBmp.getHeight();
        int width=editedBmp.getWidth();
        int pixColor;
        int x,y;
        for(x=0; x<height; x++){
            for(y=0; y<width; y++){
                pixColor=editedBmp.getPixel(y,x);
                A= Color.alpha(pixColor);
                R=Color.red(pixColor);
                G=Color.green(pixColor);
                B=Color.blue(pixColor);
                photo.setPixel((width-y-1),x,Color.argb(A,R,G,B));
            }
        }
        return photo;
    }

    private Bitmap flipHorz(){
        Bitmap photo = Bitmap.createBitmap(editedBmp.getWidth(),editedBmp.getHeight(),editedBmp.getConfig());


        int A,R,G,B;
        int height=editedBmp.getHeight();
        int width=editedBmp.getWidth();
        int pixColor;
        int x,y;
        for(x=0; x<height; x++){
            for(y=0; y<width; y++){
                pixColor=editedBmp.getPixel(y,x);
                A=Color.alpha(pixColor);
                R=Color.red(pixColor);
                G=Color.green(pixColor);
                B=Color.blue(pixColor);
                photo.setPixel(y,(height-x-1) ,Color.argb(A,R,G,B));
            }
        }
        return photo;
    }

    private Bitmap rotateRight(){
        Bitmap photo = Bitmap.createBitmap(editedBmp.getHeight(),editedBmp.getWidth(),editedBmp.getConfig());


        int A,R,G,B;
        int height=editedBmp.getHeight();
        int width=editedBmp.getWidth();
        int pixColor;
        int x,y;
        for(x=0; x<height; x++){
            for(y=0; y<width; y++){
                pixColor=editedBmp.getPixel(y,x);
                A=Color.alpha(pixColor);
                R=Color.red(pixColor);
                G=Color.green(pixColor);
                B=Color.blue(pixColor);
                photo.setPixel(height-x-1,y,Color.argb(A,R,G,B));
            }
        }
        return photo;
    }

    private Bitmap rotateLeft(){
        Bitmap photo = Bitmap.createBitmap(editedBmp.getHeight(),editedBmp.getWidth(),editedBmp.getConfig());


        int A,R,G,B;
        int height=editedBmp.getHeight();
        int width=editedBmp.getWidth();
        int pixColor;
        int x,y;
        for(x=0; x<height; x++){
            for(y=0; y<width; y++){
                pixColor=editedBmp.getPixel(y,x);
                A=Color.alpha(pixColor);
                R=Color.red(pixColor);
                G=Color.green(pixColor);
                B=Color.blue(pixColor);
                photo.setPixel(x,width-y-1,Color.argb(A,R,G,B));
            }
        }
        return photo;
    }
}
