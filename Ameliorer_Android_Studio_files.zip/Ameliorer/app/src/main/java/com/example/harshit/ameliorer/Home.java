package com.example.harshit.ameliorer;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Home extends AppCompatActivity {

    ImageButton editBtn,collageBtn;
    Uri imageUri = null;
    private static final int REQUEST_CAMERA = 1, SELECT_FILE = 0, REQUEST_CODE = 2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        editBtn = findViewById(R.id.editBtn);
        collageBtn = findViewById(R.id.collageBtn);

        getPermission();

        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectImage();

            }
        });

        collageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"This feature coming Soon",Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void SelectImage() {

        final CharSequence[] items = {"Open Camera", "Open Gallery", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(Home.this);
        builder.setTitle("Add Image");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (items[which].equals("Open Camera")) {

                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
                    String currentTimeStamp = dateFormat.format(new Date());
                    File mediaFile =
                            new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).getAbsolutePath()
                                    + "/IMG"+currentTimeStamp+".jpg");

                    Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    imageUri = Uri.fromFile(mediaFile);
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                    startActivityForResult(intent, REQUEST_CAMERA);

                } else if (items[which].equals("Open Gallery")) {

                    Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
                    startActivityForResult(intent, SELECT_FILE);


                } else if (items[which].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_CAMERA) {

                Intent intent = new Intent();
                intent.setClass(Home.this,ImageEdit.class);
                intent.putExtra("Uri", imageUri);
                startActivity(intent);



            } else if (requestCode == SELECT_FILE) {

                imageUri = data.getData();
                Intent intent = new Intent();
                intent.setClass(Home.this, ImageEdit.class);
                intent.putExtra("Uri", imageUri);
                startActivity(intent);

            }
        }
    }

    private void getPermission() {
        String[] params = null;
        String writeExternalStorage = Manifest.permission.WRITE_EXTERNAL_STORAGE;
        String readExternalStorage = Manifest.permission.READ_EXTERNAL_STORAGE;
        String Camera = Manifest.permission.CAMERA;

        int hasWriteExternalStoragePermission = ActivityCompat.checkSelfPermission(this, writeExternalStorage);
        int hasReadExternalStoragePermission = ActivityCompat.checkSelfPermission(this, readExternalStorage);
        int hasCameraPermission = ActivityCompat.checkSelfPermission(this,Camera);
        List<String> permissions = new ArrayList<String>();

        if (hasWriteExternalStoragePermission != PackageManager.PERMISSION_GRANTED)
            permissions.add(writeExternalStorage);
        if (hasReadExternalStoragePermission != PackageManager.PERMISSION_GRANTED)
            permissions.add(readExternalStorage);
        if(hasCameraPermission != PackageManager.PERMISSION_GRANTED)
            permissions.add(Camera);

        if (!permissions.isEmpty()) {
            params = permissions.toArray(new String[permissions.size()]);
        }
        if (params != null && params.length > 0) {
            ActivityCompat.requestPermissions(Home.this,
                    params,
                    100);
        }

    }
}
